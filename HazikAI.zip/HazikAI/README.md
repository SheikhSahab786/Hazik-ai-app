# Hazik AI

JARVIS-style Hinglish voice assistant for Android (Kotlin, Jetpack Compose, Gemini).

## Build
1. Open the `HazikAI` folder in Android Studio (Ladybug or newer), let Gradle sync.
2. Run on a real device (Android 8.0+). Emulators lack proper speech recognition and telephony.
3. Get a free key at https://aistudio.google.com/apikey and paste it in the app's Settings card.
4. Model name lives in `GeminiService.MODEL`.

## Permissions to grant manually

### 1. Accessibility (screen reading, taps, scrolls)
Phone Settings -> Accessibility -> Installed apps / Downloaded apps -> **Hazik AI** -> turn **On** -> Allow.
**Android 13+ "Restricted setting" block:** if the toggle is greyed out, go to
Settings -> Apps -> Hazik AI -> three-dot menu (top right) -> **Allow restricted settings**, then retry.
(This appears for apps installed outside the Play Store, i.e. an APK from Android Studio.)

### 2. Display over other apps (floating bubble)
Settings -> Apps -> Hazik AI -> **Display over other apps** (or "Appear on top") -> Allow.
In the app, tap **Grant** next to "Display over other apps" to jump straight there.

### 3. Microphone and Phone (runtime prompts)
Tap **Grant** next to Microphone, then Phone, and choose **While using the app / Allow**.
Phone grants READ_PHONE_STATE, ANSWER_PHONE_CALLS and notifications (Android 13+).

### 4. Recommended: battery
Settings -> Apps -> Hazik AI -> Battery -> **Unrestricted**, so the bubble is not killed in the background.

## Using it
Settings screen -> **Start Hazik bubble**. Tap the bubble, speak. Drag to move, long-press to quit.
Examples: "Hazik, YouTube pe Arijit Singh ke gaane chala", "WhatsApp khol", "screen pe kya likha hai?", "scroll down kar",
"(12*7)+sqrt(81) kitna hua?". When a call rings, Hazik asks whether to answer or reject.

## Known platform limits
- Third-party apps cannot silently answer calls on every OEM; Hazik tries TelecomManager first, then taps the on-screen Answer/Decline button via Accessibility.
- Banking apps and some secure screens (FLAG_SECURE) block Accessibility reading.
- "Run scripts" is limited to the built-in safe calculator; code from Gemini is shown/spoken, never executed.
- Speech recognition needs internet on most devices. Voice "gender" depends on voices installed by your TTS engine
  (Settings -> System -> Languages -> Text-to-speech -> Google -> install an English (India) male voice).
