package com.hazik.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Floating "H" bubble drawn over every app.
 *  - Tap: Hazik starts listening   - Drag: move   - Long-press: stop Hazik
 * Colours: cyan = idle, green = listening, amber = thinking, purple = speaking.
 */
class FloatingAssistantService : Service() {

    private enum class State(val color: Int, val label: String) {
        IDLE(0xFF00BCD4.toInt(), ""),
        LISTENING(0xFF00E676.toInt(), "Sun raha hoon..."),
        THINKING(0xFFFFB300.toInt(), "Soch raha hoon..."),
        SPEAKING(0xFFAB47BC.toInt(), "")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var wm: WindowManager
    private lateinit var voice: VoiceManager
    private lateinit var brain: HazikBrain
    private lateinit var callMonitor: CallMonitor

    private lateinit var root: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var status: TextView
    private lateinit var params: WindowManager.LayoutParams

    private var state = State.IDLE
    private var awaitingCallDecision = false

    companion object {
        private const val CHANNEL = "hazik_overlay"
        private const val NOTIF_ID = 42
        const val ACTION_STOP = "com.hazik.ai.STOP"
        fun start(ctx: Context) {
            val i = Intent(ctx, FloatingAssistantService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i) else ctx.startService(i)
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, FloatingAssistantService::class.java)) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        voice = VoiceManager(this)
        brain = HazikBrain(this)
        startAsForeground()
        buildOverlay()
        callMonitor = CallMonitor(this, ::onIncomingCall, ::onCallEnded).also { it.start() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    override fun onDestroy() {
        callMonitor.stop()
        voice.shutdown()
        scope.cancel()
        if (::root.isInitialized) runCatching { wm.removeView(root) }
        super.onDestroy()
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Hazik overlay", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(this, 0,
            Intent(this, FloatingAssistantService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Hazik is active")
            .setContentText("Bubble par tap karo aur bolo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(null, "Stop", stopIntent).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, notif)
    }

    // ---------- Overlay UI (plain Views: no Compose lifecycle hacks needed in a Service) ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        bubble = TextView(this).apply {
            text = "H"; textSize = 24f; setTextColor(Color.BLACK); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(dp(60), dp(60))
            elevation = dp(8).toFloat()
        }
        status = TextView(this).apply {
            textSize = 13f; setTextColor(Color.WHITE); visibility = View.GONE
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xCC10151F.toInt()) }
            maxWidth = dp(240)
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(status); addView(bubble)
        }
        setState(State.IDLE)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(240) }

        bubble.setOnTouchListener(DragTouchListener())
        wm.addView(root, params)
    }

    private fun setState(s: State, text: String? = null) {
        state = s
        bubble.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(s.color) }
        val msg = text ?: s.label
        status.text = msg
        status.visibility = if (msg.isBlank()) View.GONE else View.VISIBLE
    }

    /** Drag to move, short tap to talk, long-press to quit. */
    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0; private var startY = 0
        private var touchX = 0f; private var touchY = 0f
        private var downTime = 0L; private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY
                    downTime = System.currentTimeMillis(); moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt(); val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    params.x = startX + dx; params.y = startY + dy
                    wm.updateViewLayout(root, params)
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    if (System.currentTimeMillis() - downTime > 700) stopSelf() else onBubbleTapped()
                }
            }
            return true
        }
    }

    // ---------- Conversation flow ----------

    private fun onBubbleTapped() {
        when (state) {
            State.SPEAKING -> { voice.stopSpeaking(); setState(State.IDLE) }   // tap to interrupt
            State.LISTENING -> { voice.stopListening(); setState(State.IDLE) }
            State.THINKING -> {}
            State.IDLE -> startListening()
        }
    }

    private fun startListening() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            flash("Mic permission do Boss (app kholo)"); return
        }
        setState(State.LISTENING)
        voice.listen(
            onResult = { heard -> if (awaitingCallDecision) handleCallDecision(heard) else process(heard) },
            onError = { msg -> flash(msg) }
        )
    }

    private fun process(userText: String) {
        setState(State.THINKING, "\"$userText\"")
        scope.launch {
            val result = brain.handle(userText)
            say(result.spoken)
        }
    }

    private fun say(text: String, then: (() -> Unit)? = null) {
        setState(State.SPEAKING, text.take(120))
        voice.speak(text) { setState(State.IDLE); then?.invoke() }
    }

    private fun flash(msg: String) {
        setState(State.IDLE, msg)
        scope.launch { kotlinx.coroutines.delay(2500); if (state == State.IDLE) setState(State.IDLE) }
    }

    // ---------- Incoming calls ----------

    private fun onIncomingCall() {
        awaitingCallDecision = true
        // Ask out loud, then listen for "haan / utha lo" or "nahi / cut kar".
        say("Boss, call aa raha hai. Utha doon ya kaat doon?") { if (awaitingCallDecision) startListening() }
    }

    private fun onCallEnded() { awaitingCallDecision = false }

    private fun handleCallDecision(heard: String) {
        val t = heard.lowercase()
        awaitingCallDecision = false
        val yes = listOf("haan", "han ", "utha", "uthao", "attend", "answer", "yes", "receive", "pick")
        val no = listOf("nahi", "nahin", "kaat", "cut", "reject", "decline", "mat utha", "no")
        when {
            no.any { it in t } -> say(if (CallControl.reject(this)) "Done bhai, kaat diya." else "Arre, kaat nahi paaya yaar.")
            yes.any { it in t } -> say(if (CallControl.answer(this)) "Lo bhai, utha liya." else "Arre, utha nahi paaya yaar.")
            else -> { setState(State.IDLE); awaitingCallDecision = false }
        }
    }
}
