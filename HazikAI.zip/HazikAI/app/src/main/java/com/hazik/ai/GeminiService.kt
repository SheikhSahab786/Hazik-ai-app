package com.hazik.ai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Gemini REST client. Instead of the native tool-calling schema we force JSON output
 * (responseMimeType = application/json) in the shape: {"reply": "...", "actions": [ {...} ]}
 * which is simpler, cheaper and works the same across Gemini models.
 */
class GeminiService(private val ctx: Context) {

    companion object {
        // Gemini 1.5 Flash has been retired by Google; change this constant if you need another model.
        const val MODEL = "gemini-2.5-flash"
        private const val MAX_HISTORY = 20

        val SYSTEM_PROMPT = """
You are HAZIK, a JARVIS-like personal assistant living inside the user's Android phone.
Personality: the user's loyal Indian male best friend. Brotherly "yaar" vibe, witty, warm, confident.
Speak natural Hinglish (Hindi in Roman script mixed with English) unless the user speaks pure English/Hindi.
Use words like "Bhai", "Boss", "Arre tension mat le", "Ho gaya", "Done yaar". Never be rude or cringe.
Keep replies SHORT (1-2 sentences) because they are spoken aloud. No markdown, no emojis, no asterisks.
For code requests, give a brief spoken summary in "reply" and put the full code in "code".

You MUST answer ONLY with one JSON object, no prose outside it:
{
  "reply": "what Hazik says out loud",
  "code": "optional code snippet to show on screen, else empty string",
  "actions": [ { "type": "<action_type>", ... } ]
}
Use "actions": [] when no phone control is needed.

Available action types:
- {"type":"open_app","name":"whatsapp"}            open an installed app by its name
- {"type":"youtube_search","query":"arijit singh songs"}
- {"type":"youtube_video","video_id":"dQw4w9WgXcQ"}  only if you are sure of the ID
- {"type":"open_url","url":"https://..."}
- {"type":"click_text","text":"Subscribe"}          tap a visible UI element by its text/description
- {"type":"tap","x":540,"y":1200}                   tap raw screen pixel coordinates
- {"type":"scroll","direction":"down"}              up | down | left | right
- {"type":"type_text","text":"hello"}               type into the focused input field
- {"type":"read_screen"}                            read visible screen text; result comes back to you
- {"type":"back"} {"type":"home"} {"type":"recents"}
- {"type":"answer_call"} {"type":"reject_call"}
- {"type":"calculate","expression":"(12*7)+sqrt(81)"}  result comes back to you

When a message starts with [OBSERVATION], it is a result of your own earlier action; use it to answer the user.
Never claim an action succeeded if the observation says it failed. If unsure what the user means, ask one short question.
""".trimIndent()
    }

    data class HazikResponse(val reply: String, val code: String, val actions: List<JSONObject>)

    private val http = OkHttpClient.Builder()
        .callTimeout(40, TimeUnit.SECONDS)
        .build()

    private val history = JSONArray() // alternating user / model turns

    fun clearHistory() { while (history.length() > 0) history.remove(0) }

    suspend fun ask(text: String): Result<HazikResponse> = withContext(Dispatchers.IO) {
        runCatching {
            val apiKey = SecureStore.getApiKey(ctx)
            require(apiKey.isNotBlank()) { "NO_API_KEY" }

            history.put(turn("user", text))
            trimHistory()

            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
                .put("contents", history)
                .put("generationConfig", JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("temperature", 0.8))

            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
                .header("x-goog-api-key", apiKey) // header instead of ?key= so it never lands in logs/URLs
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    history.remove(history.length() - 1) // drop the failed user turn
                    error("HTTP_${resp.code}")
                }
                val modelText = JSONObject(raw)
                    .getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts")
                    .getJSONObject(0).getString("text")
                history.put(turn("model", modelText))
                parse(modelText)
            }
        }
    }

    private fun turn(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    private fun trimHistory() {
        while (history.length() > MAX_HISTORY) history.remove(0)
        // history must start with a user turn
        while (history.length() > 0 && history.getJSONObject(0).getString("role") != "user") history.remove(0)
    }

    /** Tolerant parser: strips code fences, falls back to plain text if the model ignores the format. */
    private fun parse(text: String): HazikResponse {
        val cleaned = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return try {
            val o = JSONObject(cleaned)
            val arr = o.optJSONArray("actions") ?: JSONArray()
            HazikResponse(
                reply = o.optString("reply", ""),
                code = o.optString("code", ""),
                actions = (0 until arr.length()).map { arr.getJSONObject(it) }
            )
        } catch (e: Exception) {
            HazikResponse(cleaned, "", emptyList())
        }
    }
}
