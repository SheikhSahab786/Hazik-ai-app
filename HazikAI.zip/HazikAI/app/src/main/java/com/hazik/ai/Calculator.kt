package com.hazik.ai

import kotlin.math.*

/** Tiny safe expression evaluator (no eval/scripting engines): + - * / % ^ ( ) sqrt sin cos tan log ln abs pi e */
object Calculator {
    fun eval(input: String): Double {
        val s = input.lowercase().replace(" ", "").replace("×", "*").replace("÷", "/").replace("x", "*")
        val p = Parser(s)
        val v = p.expr()
        require(p.pos == s.length) { "Unexpected '${s.getOrNull(p.pos)}'" }
        return v
    }

    fun format(d: Double): String =
        if (d == d.toLong().toDouble() && abs(d) < 1e15) d.toLong().toString() else "%.6f".format(d).trimEnd('0').trimEnd('.')

    private class Parser(val s: String) {
        var pos = 0
        private fun peek() = s.getOrNull(pos)

        fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') { val op = s[pos++]; val r = term(); v = if (op == '+') v + r else v - r }
            return v
        }
        private fun term(): Double {
            var v = power()
            while (peek() == '*' || peek() == '/' || peek() == '%') {
                val op = s[pos++]; val r = power()
                v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r }
            }
            return v
        }
        private fun power(): Double {
            val base = unary()
            return if (peek() == '^') { pos++; base.pow(power()) } else base
        }
        private fun unary(): Double = when (peek()) {
            '-' -> { pos++; -unary() }
            '+' -> { pos++; unary() }
            else -> primary()
        }
        private fun primary(): Double {
            val c = peek() ?: error("Unexpected end")
            if (c == '(') { pos++; val v = expr(); require(peek() == ')') { "Missing )" }; pos++; return v }
            if (c.isDigit() || c == '.') {
                val start = pos
                while (peek()?.let { it.isDigit() || it == '.' } == true) pos++
                return s.substring(start, pos).toDouble()
            }
            if (c.isLetter()) {
                val start = pos
                while (peek()?.isLetter() == true) pos++
                val name = s.substring(start, pos)
                if (name == "pi") return PI
                if (name == "e") return E
                require(peek() == '(') { "Unknown '$name'" }
                pos++; val arg = expr(); require(peek() == ')') { "Missing )" }; pos++
                return when (name) {
                    "sqrt" -> sqrt(arg); "sin" -> sin(arg); "cos" -> cos(arg); "tan" -> tan(arg)
                    "log" -> log10(arg); "ln" -> ln(arg); "abs" -> abs(arg)
                    else -> error("Unknown function '$name'")
                }
            }
            error("Unexpected '$c'")
        }
    }
}
