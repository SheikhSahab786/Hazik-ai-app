package com.hazik.ai

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.telephony.PhoneStateListener
import android.telephony.TelephonyCallback
import android.telephony.TelephonyManager

/** Fires [onRinging] when a call starts ringing and [onIdle] when it ends/is answered elsewhere. Needs READ_PHONE_STATE. */
class CallMonitor(private val ctx: Context, private val onRinging: () -> Unit, private val onIdle: () -> Unit) {

    private val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    private var callback: Any? = null
    private var lastState = TelephonyManager.CALL_STATE_IDLE

    private fun handle(state: Int) {
        if (state == lastState) return
        lastState = state
        if (state == TelephonyManager.CALL_STATE_RINGING) onRinging()
        else if (state == TelephonyManager.CALL_STATE_IDLE) onIdle()
    }

    fun start() {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val cb = object : TelephonyCallback(), TelephonyCallback.CallStateListener {
                override fun onCallStateChanged(state: Int) = handle(state)
            }
            tm.registerTelephonyCallback(ctx.mainExecutor, cb)
            callback = cb
        } else {
            @Suppress("DEPRECATION")
            val l = object : PhoneStateListener() {
                @Deprecated("Deprecated in Java")
                override fun onCallStateChanged(state: Int, phoneNumber: String?) = handle(state)
            }
            @Suppress("DEPRECATION")
            tm.listen(l, PhoneStateListener.LISTEN_CALL_STATE)
            callback = l
        }
    }

    fun stop() {
        when (val cb = callback) {
            is TelephonyCallback -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) tm.unregisterTelephonyCallback(cb)
            is PhoneStateListener -> @Suppress("DEPRECATION") tm.listen(cb, PhoneStateListener.LISTEN_NONE)
        }
        callback = null
    }
}
