package com.hazik.ai

import android.content.Context

/** Orchestrates: user text -> Gemini -> actions -> (optional observation) -> Gemini -> final spoken reply. */
class HazikBrain(ctx: Context) {
    private val gemini = GeminiService(ctx)
    private val executor = ActionExecutor(ctx)

    data class Result(val spoken: String, val code: String)

    suspend fun handle(userText: String): Result {
        var resp = gemini.ask(userText).getOrElse { return Result(friendlyError(it), "") }
        var code = resp.code

        // Up to 2 follow-up rounds so Hazik can read the screen / calculate, then answer using the result.
        repeat(2) {
            val observation = executor.executeAll(resp.actions) ?: return Result(resp.reply, code)
            resp = gemini.ask("[OBSERVATION] $observation").getOrElse { return Result(friendlyError(it), code) }
            if (resp.code.isNotBlank()) code = resp.code
        }
        return Result(resp.reply, code)
    }

    private fun friendlyError(t: Throwable): String = when {
        t.message == "NO_API_KEY" -> "Bhai, pehle Settings mein apni Gemini API key daal do."
        t.message?.startsWith("HTTP_4") == true -> "Arre boss, API key ya quota mein dikkat lag rahi hai. Key check karo."
        t is java.io.IOException -> "Net nahi chal raha yaar, internet check karo."
        else -> "Kuch gadbad ho gayi bhai, ek baar phir bolo."
    }
}
