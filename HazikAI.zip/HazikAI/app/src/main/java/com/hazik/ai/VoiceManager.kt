package com.hazik.ai

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speech-to-text (SpeechRecognizer) + text-to-speech (TextToSpeech). Call from the main thread. */
class VoiceManager(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale("en", "IN")
                pickMaleVoice()
            }
        }
    }

    /** Android has no "gender" API; we pick an en-IN/hi-IN voice whose name hints male, else rely on lower pitch. */
    private fun pickMaleVoice() {
        val voices = tts?.voices ?: return
        val preferred = voices.filter { it.locale.country == "IN" }
        val male = preferred.firstOrNull { v ->
            val n = v.name.lowercase()
            ("male" in n && "female" !in n) || n.contains("-x-ene-") || n.contains("-x-hid-") // Google en-IN / hi-IN male variants
        }
        male?.let { tts?.voice = it }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        val t = tts
        if (!ttsReady || t == null) { onDone?.invoke(); return }
        t.setSpeechRate(SecureStore.getRate(ctx))
        t.setPitch(SecureStore.getPitch(ctx))
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { onDone?.invoke() } }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post { onDone?.invoke() } }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hazik_utt")
    }

    fun stopSpeaking() { tts?.stop() }

    fun listen(onResult: (String) -> Unit, onError: (String) -> Unit) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onError("Speech recognition not available"); return }
        stopListening()
        recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) onError("Kuch sunai nahi diya") else onResult(text)
                }
                override fun onError(error: Int) {
                    onError(when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch sunai nahi diya"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission do"
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network issue"
                        else -> "Mic error $error"
                    })
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN") // handles Hinglish well; Gemini fixes the rest
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            })
        }
    }

    fun stopListening() { recognizer?.destroy(); recognizer = null }

    fun shutdown() { stopListening(); tts?.stop(); tts?.shutdown(); tts = null }
}
