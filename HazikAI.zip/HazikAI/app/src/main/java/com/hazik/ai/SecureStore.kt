package com.hazik.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Encrypted storage for the Gemini API key and voice settings. */
object SecureStore {
    private const val FILE = "hazik_secure_prefs"
    private const val KEY_API = "gemini_api_key"
    private const val KEY_RATE = "tts_rate"
    private const val KEY_PITCH = "tts_pitch"

    @Volatile private var prefs: SharedPreferences? = null

    private fun p(ctx: Context): SharedPreferences = prefs ?: synchronized(this) {
        prefs ?: run {
            val masterKey = MasterKey.Builder(ctx.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                ctx.applicationContext, FILE, masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            ).also { prefs = it }
        }
    }

    fun getApiKey(ctx: Context): String = p(ctx).getString(KEY_API, "") ?: ""
    fun setApiKey(ctx: Context, key: String) = p(ctx).edit().putString(KEY_API, key.trim()).apply()

    fun getRate(ctx: Context): Float = p(ctx).getFloat(KEY_RATE, 1.0f)
    fun getPitch(ctx: Context): Float = p(ctx).getFloat(KEY_PITCH, 0.85f) // slightly deeper = more "male"
    fun setVoice(ctx: Context, rate: Float, pitch: Float) =
        p(ctx).edit().putFloat(KEY_RATE, rate).putFloat(KEY_PITCH, pitch).apply()
}
