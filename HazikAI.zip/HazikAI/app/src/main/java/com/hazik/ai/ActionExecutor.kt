package com.hazik.ai

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telecom.TelecomManager
import android.content.pm.PackageManager
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Turns Gemini's JSON actions into real phone operations.
 * Returns an observation string for actions whose result the LLM needs (read_screen, calculate),
 * or a failure note; returns null for fire-and-forget actions that succeeded.
 */
class ActionExecutor(private val ctx: Context) {

    private val aliases = mapOf(
        "yt" to "youtube", "insta" to "instagram", "fb" to "facebook", "wa" to "whatsapp",
        "gpay" to "google pay", "maps" to "maps", "camera" to "camera", "settings" to "settings"
    )

    private val a11y get() = HazikAccessibilityService.instance
    private val needA11y = "FAILED: Accessibility service is not enabled."

    suspend fun executeAll(actions: List<JSONObject>): String? {
        val obs = StringBuilder()
        for (action in actions) {
            execute(action)?.let { obs.appendLine(it) }
            delay(800) // let the target app's UI settle before the next step
        }
        return obs.toString().trim().ifEmpty { null }
    }

    fun execute(a: JSONObject): String? = try {
        when (val type = a.optString("type")) {
            "open_app" -> openApp(a.optString("name"), a.optString("package"))
            "youtube_search" -> openYoutube("https://www.youtube.com/results?search_query=" + enc(a.optString("query")))
            "youtube_video" -> openYoutube("https://www.youtube.com/watch?v=" + a.optString("video_id"))
            "open_url" -> { view(a.optString("url")); null }
            "click_text" -> a11y?.let { if (it.clickByText(a.optString("text"))) null else "FAILED: '${a.optString("text")}' not found on screen." } ?: needA11y
            "tap" -> a11y?.let { if (it.tap(a.optDouble("x").toFloat(), a.optDouble("y").toFloat())) null else "FAILED: tap" } ?: needA11y
            "scroll" -> a11y?.let { if (it.scroll(a.optString("direction", "down"))) null else "FAILED: scroll" } ?: needA11y
            "type_text" -> a11y?.let { if (it.typeText(a.optString("text"))) null else "FAILED: no focused text field." } ?: needA11y
            "read_screen" -> a11y?.let { "[SCREEN]\n" + it.readScreen() } ?: needA11y
            "back" -> a11y?.back().let { if (it == true) null else needA11y }
            "home" -> a11y?.home().let { if (it == true) null else needA11y }
            "recents" -> a11y?.recents().let { if (it == true) null else needA11y }
            "answer_call" -> if (CallControl.answer(ctx)) null else "FAILED: could not answer call."
            "reject_call" -> if (CallControl.reject(ctx)) null else "FAILED: could not reject call."
            "calculate" -> "[CALC RESULT] " + Calculator.format(Calculator.eval(a.optString("expression")))
            else -> "FAILED: unknown action '$type'"
        }
    } catch (e: Exception) {
        "FAILED: ${a.optString("type")} -> ${e.message}"
    }

    // ---------- helpers ----------

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun launch(intent: Intent) {
        // NEW_TASK is mandatory when starting an Activity from a Service.
        // Background-start limits (Android 10+) are bypassed while our overlay window is visible.
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun view(url: String) = launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    /** Prefer the YouTube app; fall back to the browser if it is not installed. */
    private fun openYoutube(url: String): String? {
        val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube")
        return try { launch(ytIntent); null } catch (e: Exception) { view(url); null }
    }

    private fun openApp(nameRaw: String, pkgHint: String): String? {
        val pm = ctx.packageManager
        if (pkgHint.isNotBlank()) pm.getLaunchIntentForPackage(pkgHint)?.let { launch(it); return null }

        val name = aliases[nameRaw.lowercase().trim()] ?: nameRaw.lowercase().trim()
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
        val hit = apps.firstOrNull { it.first.equals(name, true) }
            ?: apps.firstOrNull { it.first.lowercase().contains(name) }
            ?: return "FAILED: app '$nameRaw' not installed."
        pm.getLaunchIntentForPackage(hit.second)?.let { launch(it); return null }
        return "FAILED: cannot launch ${hit.first}"
    }
}

/** Call answer / reject using Telecom APIs first, Accessibility button-tap as fallback. */
object CallControl {
    fun answer(ctx: Context): Boolean {
        if (ctx.checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
            try {
                (ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).acceptRingingCall()
                return true
            } catch (_: SecurityException) { /* fall through */ }
        }
        return HazikAccessibilityService.instance?.answerCallViaUi() == true
    }

    fun reject(ctx: Context): Boolean {
        // endCall() also declines a ringing call. API 28+, needs ANSWER_PHONE_CALLS.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            ctx.checkSelfPermission(android.Manifest.permission.ANSWER_PHONE_CALLS) == PackageManager.PERMISSION_GRANTED) {
            try {
                @Suppress("DEPRECATION")
                if ((ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager).endCall()) return true
            } catch (_: SecurityException) { /* fall through */ }
        }
        return HazikAccessibilityService.instance?.rejectCallViaUi() == true
    }
}
