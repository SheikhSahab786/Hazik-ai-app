package com.hazik.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Cyan = Color(0xFF00E5FF)
private val Bg = Color(0xFF0A0E14)
private val Card = Color(0xFF131A24)

class SettingsActivity : ComponentActivity() {

    // Bumped in onResume so permission indicators refresh after returning from system Settings.
    private var refresh by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = Card, onSurface = Color.White)) {
                Surface(Modifier.fillMaxSize(), color = Bg) { SettingsScreen(this, refresh) }
            }
        }
    }

    override fun onResume() { super.onResume(); refresh++ }
}

// ---------- Permission checks ----------

private fun isAccessibilityEnabled(ctx: Context): Boolean {
    val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    return enabled.split(':').any { it.startsWith("${ctx.packageName}/") && it.contains("HazikAccessibilityService") }
}
private fun has(ctx: Context, perm: String) = ctx.checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED

@Composable
private fun SettingsScreen(ctx: Context, refreshTick: Int) {
    var apiKey by remember { mutableStateOf(SecureStore.getApiKey(ctx)) }
    var showKey by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }
    var rate by remember { mutableFloatStateOf(SecureStore.getRate(ctx)) }
    var pitch by remember { mutableFloatStateOf(SecureStore.getPitch(ctx)) }
    var bubbleOn by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    // Recomputed whenever refreshTick changes
    val a11y = remember(refreshTick) { isAccessibilityEnabled(ctx) }
    val overlay = remember(refreshTick) { Settings.canDrawOverlays(ctx) }
    val mic = remember(refreshTick) { has(ctx, Manifest.permission.RECORD_AUDIO) }
    val phone = remember(refreshTick) { has(ctx, Manifest.permission.READ_PHONE_STATE) && has(ctx, Manifest.permission.ANSWER_PHONE_CALLS) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().navigationBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("HAZIK AI", color = Cyan, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
        Text("Tera apna JARVIS, bhai.", color = Color.Gray)

        // --- API key ---
        Section("Gemini API Key") {
            OutlinedTextField(
                value = apiKey, onValueChange = { apiKey = it; saved = false },
                label = { Text("API key") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = { SecureStore.setApiKey(ctx, apiKey); saved = true }) { Text("Save") }
                TextButton(onClick = { showKey = !showKey }) { Text(if (showKey) "Hide" else "Show") }
                if (saved) Text("Saved securely ✓", color = Color(0xFF00E676), fontSize = 13.sp)
            }
            Text("Get a free key from Google AI Studio. Stored encrypted on this device only.", color = Color.Gray, fontSize = 12.sp)
        }

        // --- Voice ---
        Section("Voice") {
            Text("Speed: %.2fx".format(rate), color = Color.White)
            Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.5f..2f,
                onValueChangeFinished = { SecureStore.setVoice(ctx, rate, pitch) })
            Text("Pitch: %.2f (lower = deeper)".format(pitch), color = Color.White)
            Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.5f..1.5f,
                onValueChangeFinished = { SecureStore.setVoice(ctx, rate, pitch) })
        }

        // --- Permissions ---
        Section("Permissions") {
            PermRow("Accessibility", a11y) {
                ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            PermRow("Display over other apps", overlay) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}")))
            }
            PermRow("Microphone", mic) { permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) }
            PermRow("Phone (state + answer calls)", phone) {
                val perms = mutableListOf(Manifest.permission.READ_PHONE_STATE, Manifest.permission.ANSWER_PHONE_CALLS)
                if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
                permLauncher.launch(perms.toTypedArray())
            }
        }

        // --- Bubble control ---
        val ready = overlay && mic
        Button(
            onClick = {
                if (bubbleOn) FloatingAssistantService.stop(ctx) else FloatingAssistantService.start(ctx)
                bubbleOn = !bubbleOn
            },
            enabled = ready, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)
        ) { Text(if (bubbleOn) "Stop Hazik bubble" else "Start Hazik bubble", fontWeight = FontWeight.Bold) }
        if (!ready) Text("Overlay + Microphone permission chahiye bubble start karne ke liye.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, color = Cyan, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
private fun PermRow(label: String, granted: Boolean, onFix: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).background(if (granted) Color(0xFF00E676) else Color(0xFFFF5252), CircleShape))
        Spacer(Modifier.width(12.dp))
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        if (!granted) TextButton(onClick = onFix) { Text("Grant") } else Text("OK", color = Color(0xFF00E676), fontSize = 13.sp)
    }
}
