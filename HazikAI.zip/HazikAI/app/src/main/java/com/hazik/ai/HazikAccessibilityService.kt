package com.hazik.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Eyes and hands of Hazik. Other components talk to it through [instance].
 * It does NOT record anything on its own; it only acts when ActionExecutor calls it.
 */
class HazikAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: HazikAccessibilityService? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* event-driven features can go here */ }
    override fun onInterrupt() {}
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }

    // ---------- Reading ----------

    /** Flattened visible text of the active window (capped so we don't flood the LLM). */
    fun readScreen(maxChars: Int = 3000): String {
        val root = rootInActiveWindow ?: return "Screen not readable right now."
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length >= maxChars) return
            if (n.isVisibleToUser) {
                val label = n.text?.toString()?.takeIf { it.isNotBlank() }
                    ?: n.contentDescription?.toString()?.takeIf { it.isNotBlank() }
                if (label != null) sb.append(if (n.isClickable) "[btn] " else "").append(label).append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString().take(maxChars).ifBlank { "Screen has no readable text." }
    }

    // ---------- Clicking ----------

    /** Click the first element whose text/description contains [text]. */
    fun clickByText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matches = root.findAccessibilityNodeInfosByText(text)
        for (node in matches) {
            if (!node.isVisibleToUser) continue
            // Climb to the nearest clickable ancestor
            var target: AccessibilityNodeInfo? = node
            while (target != null && !target.isClickable) target = target.parent
            if (target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
            // Fallback: tap the centre of the element's bounds
            val r = Rect().also { node.getBoundsInScreen(it) }
            if (tap(r.exactCenterX(), r.exactCenterY())) return true
        }
        return false
    }

    fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        return dispatch(path, 0, 80)
    }

    fun scroll(direction: String): Boolean {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val path = Path()
        when (direction.lowercase()) {
            // "scroll down" = reveal content below = finger swipes UP
            "down" -> { path.moveTo(w / 2, h * 0.75f); path.lineTo(w / 2, h * 0.25f) }
            "up" -> { path.moveTo(w / 2, h * 0.25f); path.lineTo(w / 2, h * 0.75f) }
            "right" -> { path.moveTo(w * 0.8f, h / 2); path.lineTo(w * 0.2f, h / 2) }
            "left" -> { path.moveTo(w * 0.2f, h / 2); path.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return dispatch(path, 0, 350)
    }

    private fun dispatch(path: Path, start: Long, duration: Long): Boolean {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, start, duration))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    // ---------- Typing ----------

    fun typeText(text: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // ---------- Global navigation ----------

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    // ---------- Call buttons (fallback when TelecomManager is not allowed) ----------

    fun answerCallViaUi(): Boolean =
        listOf("Answer", "Accept", "उत्तर दें", "Swipe up to answer").any { clickByText(it) }

    fun rejectCallViaUi(): Boolean =
        listOf("Decline", "Reject", "अस्वीकार करें").any { clickByText(it) }
}
